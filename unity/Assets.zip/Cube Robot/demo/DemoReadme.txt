I show you an example of its using ways.
You can delete this folder if you program by yourself.

HOW TO OPERATE

J KEY : OPEN/CLOSE Legs
L KEY : UP/DOWN Head
M KEY : OPEN/CLOSE Lid

------when legs are opened------

W KEY : WALK
A/D KEY : TURN LEFT/RIGHT (You can turn when you are walking)
K KEY : OPEN/CLOSE Engine (You can't open engine when legs are closed)

------when engine is opened------

UPARROW KEY : RAISE
DOWNARROW KEY : DROP
W KEY : MOVE FORWARD
S KEY : MOVE BACKWARD
D KEY : MOVE RIGHT
A KEY : MOVE LEFT



