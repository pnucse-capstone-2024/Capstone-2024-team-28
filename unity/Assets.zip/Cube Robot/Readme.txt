Thank you for buying this asset.

This contains a robot model shaped cube and its motions.

HOW TO OPERATE

J KEY : open/close legs
K KEY : open/close engine
L KEY : open/close head
I KEY : walk when legs are opened